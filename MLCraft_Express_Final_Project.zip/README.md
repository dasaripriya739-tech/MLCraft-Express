# MLCraft Express - Supervised Regression & Classification Engine

## Overview

MLCraft Express is a supervised machine learning project covering
both regression and binary classification.

## Technologies

- Python
- NumPy
- Pandas
- Scikit-learn
- Matplotlib
- Seaborn
- Joblib
- Google Colab

## Regression

Dataset: California Housing

Target: MedHouseVal

Models:

- Linear Regression
- Ridge Regression
- Lasso Regression
- Tuned Ridge Regression

Metrics:

- MSE
- RMSE
- MAE
- R2 Score

Cross-validation and GridSearchCV were used.

## Classification

Dataset: Titanic

Target: survived

Models:

- Logistic Regression
- K-Nearest Neighbors (KNN)
- Tuned Logistic Regression
- Tuned KNN

Metrics:

- Accuracy
- Precision
- Recall
- F1 Score
- ROC-AUC
- Confusion Matrix
- ROC Curve

## Preprocessing

Numerical features use median imputation and StandardScaler.

Categorical features use most-frequent imputation and OneHotEncoder.

ColumnTransformer and Pipeline were used.

## Model Serialization

Models are saved using Joblib.

Regression model:
models/regression_model.joblib

Classification model:
models/classification_model.joblib

## Project Outputs

Regression results:
results/regression_results.csv

Classification results:
results/classification_results.csv

Regression plot:
plots/regression_actual_vs_predicted.png

Classification plot:
plots/classification_accuracy_comparison.png

## Documentation

The project also contains:

- project_summary.txt
- technical_report.txt
- demo_video_script.txt
- MLCraft_Express_Presentation.pptx

## Conclusion

This project demonstrates an end-to-end supervised machine learning
workflow including preprocessing, model training, cross-validation,
hyperparameter tuning, evaluation, visualization, and serialization.